import java.util.Scanner;

public class BigNumberShift {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.print("enter a big number:");
        String input = scanner.nextLine();


        int[] number = new int[input.length()];
        for (int i = 0; i < input.length(); i++) {
           number[i] = input.charAt(i) - '0';
        }


        int[] rightShifted = shiftRight(number);
        int[] leftShifted = shiftLeft(number);

        System.out.print("right shift:");
        printArray(rightShifted);
        System.out.print("left shift:");
        printArray(leftShifted);

        scanner.close();
    }

    public static int[] shiftLeft(int[] number) {
        int[] shifted = new int[number.length];
        for (int i = 1; i < number.length; i++) {
            shifted[i - 1] = number[i];
        }
        shifted[number.length - 1] = number[0];
        return shifted;
    }

    public static int[] shiftRight(int[] number) {
        int[] shifted = new int[number.length];
        for (int i = 0; i < number.length - 1; i++) {
            shifted[i + 1] = number[i];
        }
        shifted[0] = number[number.length-1];
        return shifted;
    }


    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
        }
        System.out.println();
    }

}
